Web Scraper Instructions:

Follow the instructions on the website below to understand how to use a VENV. The folder is setup already
so you just need to activate or deactivate when needed. 
https://realpython.com/python-virtual-environments-a-primer/
(Since I have already set it up you may not need to do this but i suggest you understand it at least)

Now when in visual studio code when you run a script for the first time it will ask you to select an interpreter
make sure its the one that says ("VirtualPython":venv) Where virtual python is the name i gave it.

Now you should be able to run scripts in vs code and use libraries without installing them directly on your pc

if you have issues running the activate script in terminal use this link to make your terminal in admin mode
https://www.groovypost.com/howto/open-powershell-as-admin-on-windows-11/#:~:text=In%20the%20Terminal%20window%2C%20press,Administrator%20switch%20and%20click%20Save.
Then use the following command
Set-ExecutionPolicy RemoteSigned

MAKE SURE YOU DO THIS WHEN YOUR DONE ->
Set-ExecutionPolicy Restricted

(CMD shouldnt have this issue)




